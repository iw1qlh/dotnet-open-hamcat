﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace HamCat
{
    public class CatHRD : CatTcpBase
    {

        public CatHRD()
        {
            endPoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 7809);
        }


        private void WriteInt(uint n)
        {
            byte[] sendBytes = BitConverter.GetBytes(n);
            netStream.Write(sendBytes, 0, sendBytes.Length);
        }

        private void Write(string s)
        {
            byte[] sendBytes;

            //Debug.Write(s);

            uint size = (uint)(16 + 2 * (s.Length + 1) + 4);
            WriteInt(size);
            WriteInt(0x1234ABCD);
            WriteInt(0xABCD1234);
            WriteInt(0);
            sendBytes = Encoding.Unicode.GetBytes(s);
            netStream.Write(sendBytes, 0, sendBytes.Length);
            sendBytes = BitConverter.GetBytes((ushort)0);
            netStream.Write(sendBytes, 0, sendBytes.Length);
            WriteInt(0);
            netStream.Flush();

            //Debug.Write("->");
            if (netStream.DataAvailable)
            {
                byte[] bytes = new byte[tcpClient.Available];
                netStream.Read(bytes, 0, (int)tcpClient.Available);
                string returndata = Encoding.UTF8.GetString(bytes);
                //Debug.WriteLine(returndata);
            }

        }

        public override void TX()
        {
            Write("[1] set button-select TX~Data 1");
        }

        public override void RX()
        {
            Write("[1] set button-select TX~Data 0");
        }

        public override void LowPower()
        {
            Console.WriteLine("LowPower - Not implemented");
        }

        public override void DisableATU()
        {
            Console.WriteLine("DisableATU - Not implemented");
        }

        public override void SetFrequency(int freq)
        {
            Write(string.Format("[1] set frequency-hz {0}", freq));
        }

        public override void SetMode(Modes mode)
        {
            Console.WriteLine("SetMode - Not implemented");
        }

        public override void AskSwr()
        {
            Console.WriteLine("AskSwr - Not implemented");
        }

        public override void SendRaw(byte[] buff)
        {
            Console.WriteLine("SendRaw - Not implemented");
        }

        public override void SendRaw(string text)
        {
            Console.WriteLine("SendRaw - Not implemented");
        }

        public override void AskFrequency()
        {
            Console.WriteLine("AskFrequency - Not implemented");
        }
    }
}
